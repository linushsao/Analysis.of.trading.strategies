"simple2logReturns" <-
function(R)log1p(R)

